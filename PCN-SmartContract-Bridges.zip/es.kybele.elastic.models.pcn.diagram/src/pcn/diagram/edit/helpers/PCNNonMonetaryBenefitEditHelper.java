package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNNonMonetaryBenefitEditHelper extends PcnBaseEditHelper {
}
