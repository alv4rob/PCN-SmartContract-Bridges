package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNDelayedDependencyEditHelper extends PcnBaseEditHelper {
}
