package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNStandardDependencyEditHelper extends PcnBaseEditHelper {
}
