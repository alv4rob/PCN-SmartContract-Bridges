package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNWaitStepEditHelper extends PcnBaseEditHelper {
}
