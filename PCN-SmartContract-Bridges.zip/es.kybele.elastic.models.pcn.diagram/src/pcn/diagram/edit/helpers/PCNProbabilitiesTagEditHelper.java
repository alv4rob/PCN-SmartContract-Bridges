package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNProbabilitiesTagEditHelper extends PcnBaseEditHelper {
}
