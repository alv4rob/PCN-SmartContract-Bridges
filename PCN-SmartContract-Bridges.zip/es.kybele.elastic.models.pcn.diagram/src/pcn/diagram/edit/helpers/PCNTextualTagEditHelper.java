package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNTextualTagEditHelper extends PcnBaseEditHelper {
}
