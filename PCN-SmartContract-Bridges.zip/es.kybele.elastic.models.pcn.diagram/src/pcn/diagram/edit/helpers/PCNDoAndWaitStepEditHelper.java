package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNDoAndWaitStepEditHelper extends PcnBaseEditHelper {
}
