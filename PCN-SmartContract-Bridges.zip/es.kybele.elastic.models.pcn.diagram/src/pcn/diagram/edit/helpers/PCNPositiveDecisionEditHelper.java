package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNPositiveDecisionEditHelper extends PcnBaseEditHelper {
}
