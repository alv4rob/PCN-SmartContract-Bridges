package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNNegativeDecisionEditHelper extends PcnBaseEditHelper {
}
