package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNStandardStepEditHelper extends PcnBaseEditHelper {
}
