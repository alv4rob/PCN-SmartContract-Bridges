package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNDecisionStepEditHelper extends PcnBaseEditHelper {
}
