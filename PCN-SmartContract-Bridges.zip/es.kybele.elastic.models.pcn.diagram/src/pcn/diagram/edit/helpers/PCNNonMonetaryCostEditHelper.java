package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNNonMonetaryCostEditHelper extends PcnBaseEditHelper {
}
