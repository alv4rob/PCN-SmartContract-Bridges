package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNStartProcessStepEditHelper extends PcnBaseEditHelper {
}
