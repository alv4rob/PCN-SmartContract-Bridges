package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNInnovationStepEditHelper extends PcnBaseEditHelper {
}
