package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNMonetaryBenefitEditHelper extends PcnBaseEditHelper {
}
