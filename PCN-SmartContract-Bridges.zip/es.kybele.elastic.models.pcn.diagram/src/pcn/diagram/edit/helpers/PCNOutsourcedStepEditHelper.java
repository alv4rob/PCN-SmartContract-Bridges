package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNOutsourcedStepEditHelper extends PcnBaseEditHelper {
}
