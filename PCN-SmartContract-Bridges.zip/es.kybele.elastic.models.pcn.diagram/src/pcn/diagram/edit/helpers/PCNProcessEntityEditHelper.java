package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNProcessEntityEditHelper extends PcnBaseEditHelper {
}
