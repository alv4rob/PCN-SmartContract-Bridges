package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNOptionalDependencyEditHelper extends PcnBaseEditHelper {
}
