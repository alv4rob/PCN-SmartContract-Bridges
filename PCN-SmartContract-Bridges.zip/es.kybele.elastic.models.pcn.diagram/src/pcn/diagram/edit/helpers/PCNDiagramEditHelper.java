package pcn.diagram.edit.helpers;

/**
 * @generated
 */
public class PCNDiagramEditHelper extends PcnBaseEditHelper {
}
