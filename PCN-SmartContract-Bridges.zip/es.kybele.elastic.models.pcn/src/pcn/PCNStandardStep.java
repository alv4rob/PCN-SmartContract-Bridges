/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Standard Process Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNStandardStep()
 * @model
 * @generated
 */
public interface PCNStandardStep extends PCNRegularProcessStep {
} // PCNStandardStep
