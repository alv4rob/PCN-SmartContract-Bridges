/**
 */
package pcn.impl;

import org.eclipse.emf.ecore.EClass;

import pcn.PCNInnovationStep;
import pcn.PcnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PCN Highlight Step</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PCNInnovationStepImpl extends PCNRegularProcessStepImpl implements PCNInnovationStep {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PCNInnovationStepImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PcnPackage.Literals.PCN_INNOVATION_STEP;
	}

} //PCNInnovationStepImpl
