/**
 */
package pcn.impl;

import org.eclipse.emf.ecore.EClass;

import pcn.PCNMonetaryTag;
import pcn.PcnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PCN Monetary Tag</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PCNMonetaryTagImpl extends PCNTagImpl implements PCNMonetaryTag {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PCNMonetaryTagImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PcnPackage.Literals.PCN_MONETARY_TAG;
	}

} //PCNMonetaryTagImpl
