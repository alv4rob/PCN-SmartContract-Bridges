/**
 */
package pcn.impl;

import org.eclipse.emf.ecore.EClass;

import pcn.PCNNonMonetaryCost;
import pcn.PcnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PCN Non Monetary Cost</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PCNNonMonetaryCostImpl extends PCNNonMonetaryTagImpl implements PCNNonMonetaryCost {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PCNNonMonetaryCostImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PcnPackage.Literals.PCN_NON_MONETARY_COST;
	}

} //PCNNonMonetaryCostImpl
