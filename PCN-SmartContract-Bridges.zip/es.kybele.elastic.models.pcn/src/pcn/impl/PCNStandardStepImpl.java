/**
 */
package pcn.impl;

import org.eclipse.emf.ecore.EClass;

import pcn.PCNStandardStep;
import pcn.PcnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PCN Standard Process Step</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PCNStandardStepImpl extends PCNRegularProcessStepImpl implements PCNStandardStep {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PCNStandardStepImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PcnPackage.Literals.PCN_STANDARD_STEP;
	}

} //PCNStandardStepImpl
