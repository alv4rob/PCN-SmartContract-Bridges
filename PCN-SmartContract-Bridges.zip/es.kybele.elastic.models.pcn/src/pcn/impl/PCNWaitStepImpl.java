/**
 */
package pcn.impl;

import org.eclipse.emf.ecore.EClass;
import pcn.PCNWaitStep;
import pcn.PcnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PCN Wait Process Step</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PCNWaitStepImpl extends PCNRegularProcessStepImpl implements PCNWaitStep {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PCNWaitStepImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PcnPackage.Literals.PCN_WAIT_STEP;
	}

} //PCNWaitStepImpl
