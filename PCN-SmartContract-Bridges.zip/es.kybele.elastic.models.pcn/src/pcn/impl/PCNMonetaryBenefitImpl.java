/**
 */
package pcn.impl;

import org.eclipse.emf.ecore.EClass;

import pcn.PCNMonetaryBenefit;
import pcn.PcnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PCN Monetary Benefit</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PCNMonetaryBenefitImpl extends PCNMonetaryTagImpl implements PCNMonetaryBenefit {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PCNMonetaryBenefitImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PcnPackage.Literals.PCN_MONETARY_BENEFIT;
	}

} //PCNMonetaryBenefitImpl
