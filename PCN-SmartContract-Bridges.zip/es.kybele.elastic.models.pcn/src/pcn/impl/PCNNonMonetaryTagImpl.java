/**
 */
package pcn.impl;

import org.eclipse.emf.ecore.EClass;

import pcn.PCNNonMonetaryTag;
import pcn.PcnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PCN Non Monetary Tag</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PCNNonMonetaryTagImpl extends PCNTagImpl implements PCNNonMonetaryTag {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PCNNonMonetaryTagImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PcnPackage.Literals.PCN_NON_MONETARY_TAG;
	}

} //PCNNonMonetaryTagImpl
