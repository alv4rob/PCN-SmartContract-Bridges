/**
 */
package pcn.impl;

import org.eclipse.emf.ecore.EClass;

import pcn.PCNDoAndWaitStep;
import pcn.PcnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PCN Long Process Step</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PCNDoAndWaitStepImpl extends PCNRegularProcessStepImpl implements PCNDoAndWaitStep {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PCNDoAndWaitStepImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PcnPackage.Literals.PCN_DO_AND_WAIT_STEP;
	}

} //PCNDoAndWaitStepImpl
