/**
 */
package pcn.impl;

import org.eclipse.emf.ecore.EClass;

import pcn.PCNMonetaryCost;
import pcn.PcnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PCN Monetary Cost</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PCNMonetaryCostImpl extends PCNMonetaryTagImpl implements PCNMonetaryCost {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PCNMonetaryCostImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PcnPackage.Literals.PCN_MONETARY_COST;
	}

} //PCNMonetaryCostImpl
