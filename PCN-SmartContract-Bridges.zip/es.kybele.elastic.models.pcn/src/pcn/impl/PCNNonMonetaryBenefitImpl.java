/**
 */
package pcn.impl;

import org.eclipse.emf.ecore.EClass;

import pcn.PCNNonMonetaryBenefit;
import pcn.PcnPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PCN Non Monetary Benefit</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PCNNonMonetaryBenefitImpl extends PCNNonMonetaryTagImpl implements PCNNonMonetaryBenefit {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PCNNonMonetaryBenefitImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PcnPackage.Literals.PCN_NON_MONETARY_BENEFIT;
	}

} //PCNNonMonetaryBenefitImpl
