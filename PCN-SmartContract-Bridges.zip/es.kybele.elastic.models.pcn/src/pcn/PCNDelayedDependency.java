/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Delayed Dependency</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNDelayedDependency()
 * @model
 * @generated
 */
public interface PCNDelayedDependency extends PCNProcessStepDependency {
} // PCNDelayedDependency
