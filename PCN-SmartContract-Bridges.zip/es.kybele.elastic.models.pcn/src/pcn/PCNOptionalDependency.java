/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Optional Dependency</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNOptionalDependency()
 * @model
 * @generated
 */
public interface PCNOptionalDependency extends PCNProcessStepDependency {
} // PCNOptionalDependency
