/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Non Monetary Benefit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNNonMonetaryBenefit()
 * @model
 * @generated
 */
public interface PCNNonMonetaryBenefit extends PCNNonMonetaryTag {
} // PCNNonMonetaryBenefit
