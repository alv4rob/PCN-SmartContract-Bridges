/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Required Dependency</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNRequiredDependency()
 * @model
 * @generated
 */
public interface PCNRequiredDependency extends PCNProcessStepDependency {
} // PCNRequiredDependency
