/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Monetary Cost</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNMonetaryCost()
 * @model
 * @generated
 */
public interface PCNMonetaryCost extends PCNMonetaryTag {
} // PCNMonetaryCost
