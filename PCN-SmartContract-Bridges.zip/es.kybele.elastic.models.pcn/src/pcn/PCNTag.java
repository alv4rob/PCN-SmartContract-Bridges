/**
 */
package pcn;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Tag</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNTag()
 * @model abstract="true"
 * @generated
 */
public interface PCNTag extends EObject {
} // PCNTag
