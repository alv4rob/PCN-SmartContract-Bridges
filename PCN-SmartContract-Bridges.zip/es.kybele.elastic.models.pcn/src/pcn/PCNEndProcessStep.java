/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN End Process Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNEndProcessStep()
 * @model
 * @generated
 */
public interface PCNEndProcessStep extends PCNRegularProcessStep {
} // PCNEndProcessStep
