/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Monetary Benefit</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNMonetaryBenefit()
 * @model
 * @generated
 */
public interface PCNMonetaryBenefit extends PCNMonetaryTag {
} // PCNMonetaryBenefit
