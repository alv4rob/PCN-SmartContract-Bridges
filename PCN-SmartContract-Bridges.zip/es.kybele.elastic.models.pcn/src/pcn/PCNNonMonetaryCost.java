/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Non Monetary Cost</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNNonMonetaryCost()
 * @model
 * @generated
 */
public interface PCNNonMonetaryCost extends PCNNonMonetaryTag {
} // PCNNonMonetaryCost
