/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Monetary Tag</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNMonetaryTag()
 * @model
 * @generated
 */
public interface PCNMonetaryTag extends PCNTag {
} // PCNMonetaryTag
