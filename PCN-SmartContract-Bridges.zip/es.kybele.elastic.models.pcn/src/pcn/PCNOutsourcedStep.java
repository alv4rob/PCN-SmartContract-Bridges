/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Preparation Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNOutsourcedStep()
 * @model
 * @generated
 */
public interface PCNOutsourcedStep extends PCNRegularProcessStep {
} // PCNOutsourcedStep
