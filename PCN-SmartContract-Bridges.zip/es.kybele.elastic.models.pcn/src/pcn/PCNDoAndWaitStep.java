/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Long Process Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNDoAndWaitStep()
 * @model
 * @generated
 */
public interface PCNDoAndWaitStep extends PCNRegularProcessStep {
} // PCNDoAndWaitStep
