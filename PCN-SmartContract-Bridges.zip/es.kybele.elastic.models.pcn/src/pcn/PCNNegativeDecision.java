/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Negative Decision</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNNegativeDecision()
 * @model
 * @generated
 */
public interface PCNNegativeDecision extends PCNProcessStepDecisionDependency {
} // PCNNegativeDecision
