/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Start Process Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNStartProcessStep()
 * @model
 * @generated
 */
public interface PCNStartProcessStep extends PCNRegularProcessStep {
} // PCNStartProcessStep
