/**
 */
package pcn;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Sync Tag</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNSyncTag()
 * @model
 * @generated
 */
public interface PCNSyncTag extends EObject {
} // PCNSyncTag
