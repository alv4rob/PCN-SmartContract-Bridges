/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Highlight Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNInnovationStep()
 * @model
 * @generated
 */
public interface PCNInnovationStep extends PCNRegularProcessStep {
} // PCNInnovationStep
