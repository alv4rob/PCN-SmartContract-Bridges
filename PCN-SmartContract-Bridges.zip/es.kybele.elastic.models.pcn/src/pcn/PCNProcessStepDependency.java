/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Process Step Dependency</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNProcessStepDependency()
 * @model abstract="true"
 * @generated
 */
public interface PCNProcessStepDependency extends PCNDependency {

} // PCNProcessStepDependency
