/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Wait Process Step</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNWaitStep()
 * @model
 * @generated
 */
public interface PCNWaitStep extends PCNRegularProcessStep {
} // PCNWaitStep
