/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Positive Decision</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNPositiveDecision()
 * @model
 * @generated
 */
public interface PCNPositiveDecision extends PCNProcessStepDecisionDependency {
} // PCNPositiveDecision
