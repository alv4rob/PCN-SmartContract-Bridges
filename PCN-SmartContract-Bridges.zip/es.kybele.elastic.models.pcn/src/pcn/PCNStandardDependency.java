/**
 */
package pcn;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PCN Standard Dependency</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see pcn.PcnPackage#getPCNStandardDependency()
 * @model
 * @generated
 */
public interface PCNStandardDependency extends PCNProcessStepDependency {
} // PCNStandardDependency
